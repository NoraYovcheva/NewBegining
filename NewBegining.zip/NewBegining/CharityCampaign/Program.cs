﻿using System;

namespace CharityCampaign
{
    class Program
    {
        static void Main(string[] args)
        {
            int days = int.Parse(Console.ReadLine());
            int countOfBaker = int.Parse(Console.ReadLine());
            int countOfCakes = int.Parse(Console.ReadLine());
            int countOfWaffles = int.Parse(Console.ReadLine());
            int countOfPancakes = int.Parse(Console.ReadLine());

            const double cakePrice = 45;
            const double wafflesPrice = 5.80;
            const double pancakePrice = 3.20;

            double cakeForDay = countOfCakes * cakePrice;
            double wafflesForDay = countOfWaffles * wafflesPrice;
            double pancakeForDay = countOfPancakes * pancakePrice;

            double sumForDay = (cakeForDay + wafflesForDay + pancakeForDay)*countOfBaker;
            double allSum = sumForDay * days;
            double totalSum = allSum - (allSum / 8);
            Console.WriteLine(totalSum);
        }
    }
}
