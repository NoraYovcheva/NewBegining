﻿using System;

namespace BirthdayParty
{
    class Program
    {
        static void Main(string[] args)
        {
            double hallRent = double.Parse(Console.ReadLine());
            double cakePrice = hallRent * 0.20;
            double drinks = cakePrice - (cakePrice * 0.45);
            double animator = hallRent / 3;
            double sum = hallRent + cakePrice + drinks + animator;

            Console.WriteLine(sum);
        }
    }
}
