﻿using System;

namespace VacationBooksList
{
    class Program
    {
        static void Main(string[] args)
        {
            int pagesInBook = int.Parse(Console.ReadLine());
            double pagesInHour = double.Parse(Console.ReadLine());
            int days = int.Parse(Console.ReadLine());

            double timeForBook = pagesInBook / pagesInHour;
            double neededHour = timeForBook / days;
            Console.WriteLine(neededHour);
        }
    }
}
