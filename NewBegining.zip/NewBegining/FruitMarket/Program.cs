﻿using System;

namespace FruitMarket
{
    class Program
    {
        static void Main(string[] args)
        {
            double strawberryPrice = double.Parse(Console.ReadLine());
            double bananasInKg = double.Parse(Console.ReadLine());
            double orangesInKg = double.Parse(Console.ReadLine());
            double raspberriesInKg = double.Parse(Console.ReadLine());
            double strawberriesInKg = double.Parse(Console.ReadLine());

            double priceForRaspberries = strawberriesInKg / 2;
            double priceForOranges = priceForRaspberries - (0.40 * priceForRaspberries);
            double priceForBananas = priceForRaspberries - (0.80 * priceForRaspberries);

            double sumOfRaspberries = priceForRaspberries * raspberriesInKg;
            double sumOfOranges = priceForOranges * orangesInKg;
            double sumOfBananas = bananasInKg * priceForBananas;
            double sumOfStrawberries = strawberryPrice * strawberriesInKg;

            double totalSum = sumOfRaspberries + sumOfOranges + sumOfBananas + sumOfStrawberries;

            Console.WriteLine($"{totalSum:f2}");
        }
    }
}
