﻿using System;

namespace _08.PetShop
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.Броят на кучетата – цяло число в интервала[0… 100]
            int countOfDogs = int.Parse(Console.ReadLine());
            //2.Броят на останалите животни - цяло число в интервала[0… 100]
            int countOfOtherAnimals = int.Parse(Console.ReadLine());
            //3.Цена за една опаковка кучешка храна
            double priceForDogd = 2.50;
            //4.Цена храна за всяко друго животно
            double priceForOtherAnimals = 4;
            //5.Крайната сума 
            double finalSum = (countOfDogs * priceForDogd) + (countOfOtherAnimals * priceForOtherAnimals);
            //6.Отпечатване на конзолата 
            Console.WriteLine($"{finalSum} lv.");
        }
    }
}
