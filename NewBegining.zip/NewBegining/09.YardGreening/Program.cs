﻿using System;

namespace _09.YardGreening
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.Кв.метри, които ще бъдат озеленени – реално число в интервала[0.00… 10000.00]
            double square = double.Parse(Console.ReadLine());
            double expencive = square * 7.61;
            double discount = expencive * 0.18;
            double total = expencive - discount;

            Console.WriteLine($"The final price is: {total:f2} lv."); 
	        Console.WriteLine($"The discount is: {discount:f2} lv."); 

        }
    }
}
