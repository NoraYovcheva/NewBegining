﻿using System;

namespace _03.SquareArea
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int area = a * a;

            Console.WriteLine(area);
        }
    }
}
