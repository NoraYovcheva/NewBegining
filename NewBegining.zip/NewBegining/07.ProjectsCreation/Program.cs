﻿using System;

namespace _07.ProjectsCreation
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.Името на архитекта -текст
            string nameOfTheArchitect = Console.ReadLine();
            //2.Брой на проектите -цяло число в интервала[0… 100]
            int countOfProject = int.Parse(Console.ReadLine());
            //3.Времето нужно за един проект
            int timeNeedForOneProject = 3;
            //4.Времето нужно за всички проекти
            int timeNeedForMultipleProject = countOfProject * timeNeedForOneProject;
            //5,Печатане на конзолата
            Console.WriteLine($"The architect {nameOfTheArchitect} will need {timeNeedForMultipleProject} hours to complete {countOfProject} project/s.");
        }
    }
}
