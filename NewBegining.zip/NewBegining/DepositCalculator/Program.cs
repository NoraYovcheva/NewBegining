﻿using System;

namespace DepositCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            double deposit = double.Parse(Console.ReadLine());
            int month = int.Parse(Console.ReadLine());
            double percent = double.Parse(Console.ReadLine());

            double sum = (deposit * (percent) / 100) / 12;
            double totalSum = deposit + (month * sum);

            Console.WriteLine(totalSum);
        }
    }
}
